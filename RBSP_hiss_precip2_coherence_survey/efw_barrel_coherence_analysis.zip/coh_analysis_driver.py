####! /usr/bin/env python
#! /opt/local/bin python

#import date
import time
from Coh_analysis import Coh_analysis
import py_compile
import numpy as np
import datetime as dt
from datetime import timedelta
import sys
sys.path.append('/Users/aaronbreneman/Desktop/code/Aaron/python/spacepy/lib/python/')
from spacepy import pycdf
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.mlab as mlab
#import plasmaconst as pc


# r1 = {
#     'folder': 'run1_test',
#     'root': '/Users/aaronbreneman/Desktop/code/Aaron/RBSP/efw_barrel_coherence_analysis',
#     'probe': 'a',
#     'pre': '2',
#     'fspc': 1,
#     'date0': datetime.date(2013,12,27),
#     'date1': datetime.date(2014,02,13),
#     'payloads':['a','b','c','d','e','f','i','k','l','m','n','o','p','q','t','w','x','y']
# }

#----test run 
r1 = {
    'folder': 'run1_test',
    'root': '/Users/aaronbreneman/Desktop/code/Aaron/RBSP/efw_barrel_coherence_analysis',
    'probe': 'a',
    'pre': '2',
    'fspc': 1,
    'date0': datetime.date(2014, 1, 4),
    'date1': datetime.date(2014, 1, 7),
    'payloads':['i', 'k','l']
}



run = Coh_analysis(r1)
run.print_test()


combos = run.get_combos()
dates = run.get_dates()

restore = 0

#For each BARREL payload, create an ascii file for entire mission.
plds = r1['payloads']

for payload in plds: 
    result = run.create_barrel_missionwide_ascii(payload, dates)

for i in range(len(combos)): 
    result = run.create_coh_ascii(combos[i], r1['pre'], r1['fspc'])












import subprocess
import os
import numpy as np

#Read in entire-mission ascii files for individual payloads. These files are
#created from create_barrel_missionwide_ascii


vals = []
path = '/Users/aaronbreneman/Desktop/code/Aaron/RBSP/efw_barrel_coherence_analysis/barrel_missionwide/'
fn = 'barrel_2K_fspc_fullmission.txt'
f = open(path+fn, 'r')
print f
vals = f.read()
f.close
vals = vals.split("\n")

time = []
quality = []
fspc = []
lshell = []
mlt = []

for i in range(2, len(vals)-1): 
    tmp = vals[i]
    
    time.append(tmp[1:15])
    quality.append(tmp[18:21])
    fspc.append(tmp[24:33])
    lshell.append(tmp[35:40])
    mlt.append(tmp[43:47])
    
    
    #Changing these to floats will get rid of the "'" separating each value. 
    #I still have to pass these to IDL as strings, but this makes turning them into
    #floats within IDL easier.
# time = np.array(time)
# quality = np.array(quality)
# fspc = np.array(fspc)
# lshell = np.array(lshell)
# mlt = np.array(mlt)

time = [float(x) for x in time]
fspc = [float(x) for x in fspc]
lshell = [float(x) for x in lshell]
mlt = [float(x) for x in mlt]
