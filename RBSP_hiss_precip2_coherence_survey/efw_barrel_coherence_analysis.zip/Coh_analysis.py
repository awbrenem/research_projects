class Coh_analysis:
    
    def __init__(self,params):
        self.__dict__.update(params)
        

    def print_test(self):
        print self.probe


    def get_combos(self):
        import string
        n = len(self.payloads)
        loopv = n*(n+1)/2 - n
        combos = []

        for x in range(n):
            for y in range(x + 1, n):
                if x != y: combos.append(self.payloads[x]+self.payloads[y])

        for x in range(0,len(combos)): combos[x] = combos[x].upper()
        return combos
    

    def get_dates(self):
        import datetime

        x = self.date1 - self.date0
        ndays = x.days
        dates = []
        for x in range(0,ndays): dates.append(self.date0 + datetime.timedelta(days=x))
    
        return dates
 

    def create_barrel_missionwide_ascii(self, payload, dates): 
        import subprocess
 
        dtmp = []
        for i in range(len(dates)): dtmp.append(dates[i].isoformat())

        dateS = dtmp[0]
        dateE = dtmp[len(dtmp)-1]

        #Combine all the appropriate ephem files into tplot variables
        exit_code = subprocess.call(['/Applications/itt/idl71/bin/idl','-e',
                                     'create_barrel_missionwide_ascii','-args',
                                     '%s'%payload,'%s'%dateS,'%s'%dateE,'%s'%self.pre,
                                     '%s'%self.fspc])


    def create_coh_ascii(self, combo, pre, fspc): 
        import subprocess

        # #Read in entire-mission ascii files for individual payloads. These files are
        # #created from create_barrel_missionwide_ascii

        # path = '/Users/aaronbreneman/Desktop/code/Aaron/RBSP/efw_barrel_coherence_analysis/barrel_missionwide/'
        # fn = 'barrel_2K_fspc_fullmission.txt'
        # f = open(path+fn, 'r')
        # print f
        # vals = f.read()
        # f.close
        # vals = vals.split("\n")

        # time = []
        # quality = []
        # fspc = []
        # lshell = []
        # mlt = []
        
        # for i in range(2, len(vals)-1): 
        #     tmp = vals[i]            
        #     time.append(tmp[1:15])
        #     fspc.append(tmp[24:33])
        #     lshell.append(tmp[35:40])
        #     mlt.append(tmp[43:47])



        # time = [float(x) for x in time]
        # fspc = [float(x) for x in fspc]
        # lshell = [float(x) for x in lshell]
        # mlt = [float(x) for x in mlt]


        # #Combine all the appropriate ephem files into tplot variables
        # exit_code = subprocess.call(['/Applications/itt/idl71/bin/idl','-e',
        #                              'create_coh_ascii','-args',
        #                              '%s'%combo,'%s'%time[0:1000],
        #                              '%s'%fspc[0:1000],'%s'%lshell[0:1000],'%s'%mlt[0:1000]])


        #Combine all the appropriate ephem files into tplot variables
        exit_code = subprocess.call(['/Applications/itt/idl71/bin/idl','-e',
                                     'create_coh_ascii','-args',
                                     '%s'%combo, '%s'%pre, '%s'%fspc])





